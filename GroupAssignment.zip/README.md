# CSU22012-group-project-
Data Structures and Algorithms Group Project-Vancouver public transport system

Link to repository - https://github.com/conordoh98/CSU22012-group-project

Group Members list and contributions

Conor Doherty - Created the github repository. Created the basic java project. Wrote the frontInterface.java file which is the interface for the user to pick a function, enter the search query information and returns data. Recorded video demo.

Mohamed Difallah - Created the ShortestPath class for finding the path between two stops under the given specifications.

Aaron Bruce - I did part 2 of the assignment 
sheet where I had to create a ternary 
search tree to store bus stop names and 
functionality to search for these bus stops. 
I also comitted BusStopSearchTest.java that
provided Conor with the necessary setup for 
creating a ternary search tree and storing 
the bus stops in that tree.


John Cosgrove -  Created tripSearch.java and coded part 3 of the assignment. Was quite simplistic but had to ensure the class had all error checking necessary. Then helped Conor integrate it with interface. Also created the .zip containing the deliverables which the group submitted.
